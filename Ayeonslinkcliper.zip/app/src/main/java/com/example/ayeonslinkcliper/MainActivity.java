package com.example.ayeonslinkcliper;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button exit, btn_1, btn_2, btn_3, btn_4, btn_5;
    Button naver, google, youtube;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Intent inte = getIntent();
        String url = inte.getAction();
        String type = inte.getType();
        final String sharedText = inte.getStringExtra(Intent.EXTRA_TEXT);

        exit = findViewById(R.id.naver);
        btn_1 = findViewById(R.id.button1);
        btn_2 = findViewById(R.id.button23);
        btn_3 = findViewById(R.id.button3);
        btn_4 = findViewById(R.id.button4);
        btn_5 = findViewById(R.id.button5);
        naver = findViewById(R.id.naver);
        google = findViewById(R.id.google);
        youtube = findViewById(R.id.youtube);

            btn_1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent page1 = new Intent(getApplication(), page1.class);
                    page1.putExtra("url", sharedText);
                    startActivity(page1);
                }
            });

            btn_2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent page2 = new Intent(getApplication(), page2.class);
                    page2.putExtra("url", sharedText);
                    startActivity(page2);
                }
            });

            btn_3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent page3 = new Intent(getApplicationContext(), page3.class);
                    page3.putExtra("url", sharedText);
                    startActivity(page3);
                }
            });

            btn_4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent page4 = new Intent(getApplication(), page4.class);
                    page4.putExtra("url", sharedText);
                    startActivity(page4);
                }
            });

            btn_5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent page5 = new Intent(getApplication(), page5.class);
                    page5.putExtra("url", sharedText);
                    startActivity(page5);
                }
            });

            naver.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.naver.com/"));
                    startActivity(intent);
                }
            });

            youtube.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/"));
                    startActivity(intent);
                }
            });

            google.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.co.kr/?gws_rd=ssl#spf=1581408112144"));
                    startActivity(intent);
                }
            });
        }
    }
