package com.example.ayeonslinkcliper;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class    page1 extends AppCompatActivity {
Button quit1,append1;
TextView text1;
EditText edit1;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page1);
        quit1=findViewById(R.id.button1);
        text1=findViewById(R.id.textView1);
        edit1=findViewById(R.id.editText1);
        append1=findViewById(R.id.append1);

        Intent intent = getIntent();
        final String link = intent.getStringExtra("url");
        SharedPreferences sf = getSharedPreferences("sFile",MODE_PRIVATE);
        String text = sf.getString("text1","");

        text1.setText(text);

        append1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                text1.append("\n"+link+"\n");
            }
        });


        quit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent return_to = new Intent(getApplication(),MainActivity.class);
                startActivity(return_to);
            }
        });
    }


    @Override
    protected void onStop() {
        super.onStop();

        SharedPreferences sharedPreferences = getSharedPreferences("sFile",MODE_PRIVATE);



        //저장을 하기위해 editor를 이용하여 값을 저장시켜준다.
        SharedPreferences.Editor editor = sharedPreferences.edit();

            String text = text1.getText().toString(); // 사용자가 입력한 저장할 데이터
        editor.putString("text1",text);// key, value를 이용하여 저장하는 형태
            editor.commit();
    }


}
