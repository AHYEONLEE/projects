package com.example.ayeonslinkcliper;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class page3 extends AppCompatActivity {
Button quit3,button3,append3;
    TextView text3;
    EditText edit3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page3);

        quit3=findViewById(R.id.button3);
        text3=findViewById(R.id.textView3);
        edit3=findViewById(R.id.editText3);
        append3=findViewById(R.id.append3);
        SharedPreferences sf = getSharedPreferences("sFile",MODE_PRIVATE);
        String text = sf.getString("text3","");

        text3.setText(text);
        append3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = getIntent();
                String link = intent.getStringExtra("url");
                text3.append("\n"+link+"\n");
            }
        });
        button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent return_to = new Intent(getApplication(),MainActivity.class);
                startActivity(return_to);
            }
        });
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
    }
public void return_to3(View view) {

    Intent return_to = new Intent(getApplication(),MainActivity.class);
    startActivity(return_to);
}
    @Override
    protected void onStop() {
        super.onStop();

        SharedPreferences sharedPreferences = getSharedPreferences("sFile",MODE_PRIVATE);



        //저장을 하기위해 editor를 이용하여 값을 저장시켜준다.
        SharedPreferences.Editor editor = sharedPreferences.edit();

        String text = text3.getText().toString(); // 사용자가 입력한 저장할 데이터

        editor.putString("text3", text); // key, value를 이용하여 저장하는 형태
        editor.commit();
    }
}
