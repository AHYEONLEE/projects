package ahyeon;

import javax.imageio.ImageIO;
import javax.swing.*;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.awt.BasicStroke;

class MyPen2D extends Polygon
{
    boolean bFill = false;
    Color color;
    Color getColor() { return color; }
    void setColor(Color color) { this.color = color; }
    int lineWidth;
}

class MyLine2D extends Line2D.Double
{
    boolean bFill = false;
    Color color;
    Color getColor() { return color; }
    void setColor(Color color) { this.color = color; }
    MyLine2D() { super(); }
    MyLine2D(int x0, int y0, int x1, int y1) {
        super(x0, y0, x1, y1);
    }
    int lineWidth;
}

class MyRectangle2D extends Rectangle2D.Double
{
    boolean bFill = false;
    Color color;
    Color getColor() { return color; }
    void setColor(Color color) { this.color = color; }
    MyRectangle2D() { super(); }
    MyRectangle2D(int x0, int y0, int x1, int y1)
    {
        this.x = Math.min(x0, x1);
        this.y = Math.min(y0, y1);
        this.width = Math.abs(x0-x1);
        this.height = Math.abs(y0-y1);
    }
    int lineWidth;
}

class MyRoundRectangle2D extends RoundRectangle2D.Double
{
    boolean bFill = false;
    Color color;
    Color getColor() { return color; }
    void setColor(Color color) { this.color = color; }
    MyRoundRectangle2D() { super(); }
    MyRoundRectangle2D(int x0, int y0, int x1, int y1)
    {
        this.x = Math.min(x0, x1);
        this.y = Math.min(y0, y1);
        this.width = Math.abs(x0-x1);
        this.height = Math.abs(y0-y1);
        this.archeight = this.arcwidth = 10;
    }
    int lineWidth;
}

public class MyCanvas extends JPanel implements MouseListener, MouseMotionListener {
    int x0=-1, y0=-1, x1, y1;
    MyPen2D pen;
    Mode drawingMode=Mode.PEN;
    ArrayList<Shape> objectList;
    BufferedImage bgImage=null;
    Color curColor;
    int curLineWidth = 1;

    public MyCanvas()
    {
        objectList = new ArrayList<>();

        curColor = Color.BLACK;
        addMouseListener(this);
        addMouseMotionListener(this);
    }
    void loadImage()
    {
        File input = new File("saved.jpg");
        try {
            bgImage = ImageIO.read(input);
        } catch(IOException e) {
            bgImage = null;
        }
        // clear all objects
        objectList.clear();
        x0 = y0 = -1;
        repaint();
    }
   public BufferedImage mergeDrawings()
    {
       BufferedImage bImage = new BufferedImage(getWidth(), getHeight(), BufferedImage.TYPE_INT_RGB);
       Graphics2D g = bImage.createGraphics();
       g.setColor(getForeground());
       g.setBackground(getBackground());
       paintComponent(g);
       return bImage;
    }

    void saveImage()
    {
    	 bgImage = mergeDrawings();   
         JFileChooser fc = new JFileChooser(); 
         if ( fc.showSaveDialog(this) == JFileChooser.APPROVE_OPTION ) {
            File file = fc.getSelectedFile();
     
            try {
               ImageIO.write(bgImage, "jpg", file);
            }

        catch(IOException e) {
            System.out.println(e);
    }
         }
         }
    //새 이미지 
    void newImage()
    {
       x0 = y0 = -1;
       bgImage = null;
        objectList.clear();
        repaint();
    }
    
    void setMode(Mode mode)
    {
        drawingMode = mode;
        System.out.println(mode);
    }

    void setColor(Color color)
    {
        curColor = color;
    }
    
    void setWidth(int width)
    {
       curLineWidth = width;
    }
    
    @Override
    public void mouseClicked(MouseEvent mouseEvent) {
    
    }

    @Override
    public void mousePressed(MouseEvent mouseEvent) {
        x0 = x1 = mouseEvent.getX();
        y0 = y1 = mouseEvent.getY();
        if( drawingMode == Mode.PEN ) {
            pen = new MyPen2D();
            
            pen.addPoint( x0, y0);
        }
        repaint();

    }

    @Override
    public void mouseDragged(MouseEvent mouseEvent) {
        x1 = mouseEvent.getX();
        y1 = mouseEvent.getY();
        if( drawingMode == Mode.PEN ) {
            pen.addPoint(x1, y1);
        }
        repaint();
    }

    @Override
    public void mouseReleased(MouseEvent mouseEvent) {
        x1 = mouseEvent.getX();
        y1 = mouseEvent.getY();
        switch (drawingMode)
        {
            case PEN:
                pen.setColor(curColor);
                pen.lineWidth = curLineWidth;
                objectList.add(pen);
                break;
            case LINE:
                MyLine2D l = new MyLine2D(x0, y0, x1, y1);
                l.setColor(curColor);
                l.lineWidth = curLineWidth;
                objectList.add(l);
                break;
            case FRECT:
            case RECT:
                MyRectangle2D r = new MyRectangle2D(x0, y0, x1, y1);
                if( drawingMode == Mode.FRECT)
                    r.bFill = true;
                r.setColor(curColor);
                r.lineWidth = curLineWidth;
                objectList.add(r);
                break;
            case FRRECT:
            case RRECT:
                MyRoundRectangle2D rr = new MyRoundRectangle2D(x0, y0, x1, y1);
                if( drawingMode == Mode.FRRECT)
                    rr.bFill = true;
                rr.setColor(curColor);
                rr.lineWidth = curLineWidth;
                objectList.add(rr);
                break;
            case CIRCLE:
               MyRectangle2D rrr = new MyRectangle2D(x0,y0,x1,y1);
               if( drawingMode == Mode.CIRCLE)
                  rrr.bFill =true;
               rrr.setColor(curColor);
               rrr.lineWidth =curLineWidth;
               objectList.add(rrr);
               break;
            
          
          
        }
    }

    @Override
    public void mouseEntered(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseExited(MouseEvent mouseEvent) {

    }

    @Override
    public void mouseMoved(MouseEvent mouseEvent) {

    }

    void drawimages(Graphics g)
    {
        Graphics2D g2 = (Graphics2D)g;
        if( bgImage != null )
            g.drawImage(bgImage, 0, 0, null);
        
        // draw saved object
        for (int i = 0; i < objectList.size() ;i++) {
            Shape s = objectList.get(i);
            
            switch(s.getClass().getName())
            {
                case "MyPen2D":
                    MyPen2D p = (MyPen2D)s;
                    g.setColor(p.getColor());
                    // 굵기 구현을 위해 Stroke 설정
                    g2.setStroke(new BasicStroke(p.lineWidth, BasicStroke.CAP_ROUND,0));
                    g.drawPolyline(p.xpoints, p.ypoints, p.npoints);
                    //g2.draw(p);
                    break;
                case "MyLine2D":
                    MyLine2D l = (MyLine2D)s;
                    g2.setColor(l.getColor());
                    g2.setStroke(new BasicStroke(l.lineWidth, BasicStroke.CAP_ROUND,0));
                    g2.draw(l);
                    break;
                case "MyRectangle2D":
                    MyRectangle2D r = (MyRectangle2D)s;
                    g2.setColor(r.getColor());
                    g2.setStroke(new BasicStroke(r.lineWidth, BasicStroke.CAP_ROUND,0));
                    if( r.bFill == true )
                        g2.fill(r);
                    else
                        g2.draw(r);
                    break;
                case "MyRoundRectangle2D":
                    MyRoundRectangle2D rr = (MyRoundRectangle2D)s;
                    g.setColor(rr.getColor());
                    g2.setStroke(new BasicStroke(rr.lineWidth, BasicStroke.CAP_ROUND,0));
                    if( rr.bFill == true )
                        g2.fill(rr);
                    else
                        g2.draw(rr);
                    break;
                    
            }
        }

      
        if( x0 != -1 ) {
            g.setColor(curColor);
            // 굵기 구현을 위해 Stroke 설정
            g2.setStroke(new BasicStroke(curLineWidth, BasicStroke.CAP_ROUND,0));
            // draw current object
            switch(drawingMode)
            {
                case PEN:
                    g.drawPolyline(pen.xpoints, pen.ypoints, pen.npoints);
                    break;
                case LINE:
                    g.drawLine(x0, y0, x1, y1);
                    break;
                case RECT:
                    g.drawRect(Math.min(x0,x1), Math.min(y0,y1), Math.abs(x1-x0), Math.abs(y1-y0));
                    break;
                case FRECT:
                    g.fillRect(Math.min(x0,x1), Math.min(y0,y1), Math.abs(x1-x0), Math.abs(y1-y0));
                    break;
                case RRECT:
                    g.drawRoundRect(x0, y0, x1-x0, y1-y0, 10, 10);
                    break;
                case FRRECT:
                    g.fillRoundRect(x0, y0, x1-x0, y1-y0, 10, 10);
                    break;
                case CIRCLE:
                     g.drawOval(Math.min(x0,x1), Math.min(y0,y1), Math.abs(x1-x0), Math.abs(y1-y0));
                    break;
             
            
                    
            }
        }

    }
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);


        drawimages(g);
    }
}