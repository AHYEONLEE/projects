#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main()
{
	int state,Sn,Sf,Sl,random,a=0;
	int i=0,l,f,m;
	int window_size=0, bit,packet_size;
	int window[window_size];
	int packet_num[packet_size];
	int success=0,fail=0,time;
	int percentage;
	int v ;
	double throughput;
	typedef enum _boolean {
    FALSE,
    TRUE
} boolean;
int pr;
	boolean ack_check[window_size];
int sd;
int back;

	



	printf("Input reciprocation time [ms] ? : ");
	scanf_s("%d",&time);
	
	printf("input usable bits : ");
	scanf_s("%d",&bit);
	packet_size=pow(2,bit-1);
	printf("%d", packet_size);
	
	printf("\ninput window size less then %d : ",(packet_size+1));
	scanf_s("%d",&window_size);
		for(i=0;i<window_size;i++){
	
	   ack_check[i]==true;
}
	
	
	
	for(a=0;a<window_size;a++){
	window[a]=a;
	printf("%d\n",window[a]);
		}
		printf("\n press percentage % : ");
			scanf_s("%d",&percentage);
			
	printf("\nWhat should I do? (exit= 0, start= 1) : ");
	scanf_s("%d",&state);
		if(state==0){
	printf("It's over");
	
	}
		Sn=0;
	Sf=Sn;
	Sl=window_size-1;
	
	printf("preset Sf:%d Sn:%d Sl:%d \n", Sf ,Sn, Sl);
	
	if(state==0){
	printf("It's over");
	
	}
	
	
	
	
	//���� ���ý� 
	else{
	

		printf("\n\n\n");
	
			
	
for(a=0;a<999;a++)
	{		

	

	
	 random=rand()%99;
	 
	
//���� �� ��Ŷ�� ACK�� ���� ���� 
	if(random<percentage-1){
		
		
		
		success++;
		
		ack_check[Sn]=true;
		
		Sn=Sn+1;
		
		ack_check[Sn]=true;
			
			
			
		if((packet_size-1)<(Sn))
		Sn=Sn-((packet_size));
		
	
		
		if((packet_size-1)<(Sf))
		Sf=Sf-((packet_size));

	for(f=0;f<Sl;f++){
		if(ack_check[f]==false)
		break;
		else if(ack_check[f]==true)
	
			if((packet_size-1)<(Sf))
			Sf=Sf-(packet_size);

		// Sl �߰�; 
		Sl=Sf+(window_size-1);
		
		
			if((packet_size-1)<Sl)
	Sl=Sl-(packet_size);
	
		if((packet_size-1)<(Sf))
	Sf=Sf-((packet_size));

}
	
	
		
		random= rand()%99;	
	
		
 int v = Sn-1;
 if(v-1<0){
 v==0;
 }
 
	
	printf("\n %d Error free \n",(v));
		for(i=Sf;i<=sd;i++){
	
		if(ack_check[i]==false){
			Sf=i-1;
			
			if(0>Sf){
			
			Sf=Sf+(packet_size-1);
}
			
		
			
		
			ack_check[i]==true;
	
		}

	sd= Sn;
	back=Sf;
	}
	
		if((Sf==0)&&(Sl=Sf+(window_size-1))){
			Sf++;
		}
			Sl=Sf+(window_size-1);
			
			if((packet_size-1)<(Sf))
			Sf=Sf-((packet_size));
		
		
		printf("Sf:%d Sn:%d Sl:%d\n", Sf ,Sn, Sl);
	}

	

		
		//���� �� ��Ŷ�� ACK�� ����  
	else{

		fail++;
		ack_check[Sn]=false;
			Sn++;
			//ó�� 
	
		
		
		
			if((packet_size-1)<Sl)
			Sl=Sl-(packet_size);
			if((packet_size-1)<(Sn))
			Sn=Sn-((packet_size));
		
		//Error�� Sf Sl ���� 
		
			if((packet_size-1)<(Sf))
			Sf=Sf-(packet_size-1);
			
		
				
 int v = Sn-1;
 if(v-1<0){
 v++;
 }
 


	printf("\n %d packet Error \n",(v));
	





		

	
	
	
	Sl=Sf+(window_size-1);
			if((packet_size-1)<Sl)
			Sl=Sl-(packet_size);

		sd=Sn;
		
		printf("Sf:%d Sn:%d Sl:%d\n", Sf ,Sn, Sl);
	}
	
	
	

	

	
	
	//Ÿ�ӿ������� �����̵� ó��
	
		
	
	
	
	
	
	
	
	
	
	//�ǻ���� 
	printf("\nWhat should I do? (exit= 0, start= 1 ) : ");
	scanf_s("%d",&state);
	printf("\n ");
			if(state==0){
	printf("probability: %f , delay:%f[ms] , throughput:%f ",(double)success/((double)success+(double)fail),((double)success+(double)fail)*time ,(double)success/((double)success+(double)fail)*time);
	a=999;
	
	}
		
		
		
		else{
		
			if(Sn==Sl){
		
		for(i=Sf;i<=sd;i++){
	
		if(ack_check[i]==false){
			Sn=i;
			printf("\n\n\nResending");
			Sf=Sn;
			Sl=i+(window_size-1);
			success++;
			
			printf("\n Sf:%d Sn:%d Sl:%d \n", Sf ,Sn, Sl);
			ack_check[i]==true;
	
		}
		
		}
			printf("\n\n\n Window slides send next \n", Sf ,Sn, Sl);
			back= Sf;
			
	}
		
		
	}
		
		
		
		//Stop�� 

	
	
	}


		
	}
	
	
	
	return 0;
	
}




