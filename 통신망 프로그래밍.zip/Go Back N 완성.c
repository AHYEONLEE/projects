#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

int main()
{
	int state,Sn,Sf,Sl,random,a=0;
	int i=0;
	int window_size=0, bit,packet_size;
	int window[window_size];
	int packet_num[packet_size];
	int success=0,fail=0,time;
	int percentage;
	double throughput;
	int re;
	typedef enum _boolean {
    FALSE,
    TRUE
} boolean;
	boolean ack_check[window_size];
int window_max;




	printf("Input reciprocation time [ms] ? : ");
	scanf_s("%d",&time);
	
	printf("input usable bits : ");
	scanf_s("%d",&bit);
	
	packet_size=pow(2,bit)-1;
	
	printf("%d", packet_size);
	
	printf("\ninput window size less then %d : ",(packet_size+1));
	scanf_s("%d",&window_size);
		for(i=0;i<window_size;i++){
	
	   ack_check[i]==(false);
}
	
	
	
	for(a=0;a<window_size;a++){
	window[a]=a;
	printf("%d\n",window[a]);
		}
		printf("\n press percentage % : ");
			scanf_s("%d",&percentage);
	printf("\nWhat should I do? (exit= 0, start= 1 ) : ");
	scanf_s("%d",&state);
	
	if(state==0){
	printf("It's over");
	
	}
	
	
	
	
	
	else{
	
	Sn=0;
	Sf=Sn;
	Sl=window_size-1;
	
	printf("preset Sf:%d Sn:%d Sl:%d \n", Sf ,Sn, Sl);
		printf("\n");
	
	
	
for(a=0;a<999;a)
	{

	 random=rand()%99;
	
	
	 if(random<percentage-1){
		success++;

	random= rand()%99;
	if((packet_size-1)<(Sf))
	Sf=Sf-((packet_size));
	else
	Sf++;
	
		 random= rand()%99;
	if((packet_size-1)<(Sl))
	Sl=Sl-((packet_size));
	else
	Sl++;
	
	Sn=Sf;

	printf("Error Free\nSf:%d Sn:%d Sl:%d\n", Sf ,Sn, Sl);	
	printf("\nWhat should I do? (exit=0, start= 1 ) : ");
	scanf_s("%d",&state);
	
	if(state==0){
	
	printf("probability: %f , delay:%f[ms] , throughput:%f ",(double)success/((double)success+(double)fail),((double)success+(double)fail)*time ,(double)success/((double)success+(double)fail)*time);
	
	a=999;}
	
	
	
	
	
}

	

	
	else{
		fail++;
	printf("\n	Error \n");
	
	for(re=0;re<=(Sl-Sn);re++){
	printf("\ndiscarded packet\n");
	fail++;
	printf("Sf:%d Sn:%d Sl:%d\n", Sf ,(Sn+re), Sl);
}

	Sn=Sf;
	printf("so state is Sf:%d Sn:%d Sl:%d\n", Sf ,Sn, Sl);
	printf("\nWhat should I do? (exit= 0, start= 1 ) : ");
	scanf_s("%d",&state);
	printf("\n ");
		if(state==0){
printf("probability: %f , delay:%f[ms] , throughput:%f ",(double)success/((double)success+(double)fail),((double)success+(double)fail)*time ,(double)success/((double)success+(double)fail)*time);
	a=999;}
	}


		
	}
}
return 0;
}
