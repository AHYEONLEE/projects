#include <stdio.h>
#include <stdlib.h>


int main()
{
	int state,Sn,Sf,Sl,random,a=0;
    int percentage=0;
    int success=0,fail=0;
	printf("\nWhat should I do? (exit=0, start=any key) : ");
	scanf_s("%d",&state);
		printf("\n press percentage % : ");
			scanf_s("%d",&percentage);
	if(state==0){
	printf("It's over");
	
	}
	else{
		Sn=0;
	Sl=1;
	Sf=0;
	printf("preset Sf:%d Sn:%d Sl:%d\n", Sf ,Sn, Sl);
	
for(a=0;a<1;a){

	
	
	random= rand()%99;

	if(random<percentage-1){
			success++;
	printf("\nack arrive  \nSf:%d Sn:%d Sl:%d", Sf+1 ,Sn+1, Sl);
	printf("\nWhat should I do? (exit=0, start=any key) : ");
	scanf_s("%d",&state);
			if(state==0){
	printf("probability: %f",(double)success/((double)success+(double)fail));
	a=1;}

	}

	
	else{
		fail++;
	printf("\nack is not arrived \n Sf:%d Sn:%d Sl:%d", Sf ,Sn, Sl);
	printf("\nWhat should I do? (exit=0, start=any key) : ");
	scanf_s("%d",&state);
	if(state==0){
	printf("probability: %f",(double)success/((double)success+(double)fail));
	a=1;}
	

		
	}
}
}
return 0;
}

